# USER.md - About Your Human

*Learn about the person you're helping. Update this as you go.*

- **Name:** Badro
- **What to call them:** Badro
- **Pronouns:** *(optional)*
- **Timezone:** GMT+1
- **Notes:** Middle ground between formal and casual — not too stiff, not too loose

## Context

*(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)*

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
